public class Teste {

    public static void main(String[] args) {

        ListaLigada ll = new ListaLigada();
        ll.insereNode(1);
        ll.insereNode(2);
        ll.insereNode(3);
        ll.insereNode(4);

        ll.exibe();
    }

}
